Collaboration:
Member1
Name: Senqi Zhang
NetID: szhang71
Assignment Number: Project 1
Lab Section: T/R 11:05-12:20
TA:Mustafa Ali

Member2
Name: Yue Liu
NetID: yliu165
Assignment Number: Project 1
Lab Section: T/r 9:40-10:55
TA: Sereen Assi

Project1
Extra Credit:
1.We add some randomness to the sentences generated.
We create four arrays to select from them.


After the instruction the player enters "go" to start the game.
The height and the distance are randomly generated between 1-20.
Players will be informed of the distance and height.
Then they will be aksed to iput a distance and a height.
Programm will compute whether the projectile make it over the wall.
Then there will be two scenarios:
A. If the projectile makes it over the wall
The player has the option to continue the game or quit.

B. If the projectile doesn't make it over the wall
The player has the option to :
1.Try again with the same distance and height.
2.Skip this round and start with new distance and height.
3.Quit the game.

Players will be informed of their score at the end of each try and when they quit the game.




